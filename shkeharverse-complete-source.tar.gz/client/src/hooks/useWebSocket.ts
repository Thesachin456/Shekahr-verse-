import { useState, useEffect, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  displayName: string;
  status: string;
  initials: string;
  avatarColor: string;
}

interface Message {
  id: string;
  content: string;
  type: 'message' | 'system';
  createdAt: Date;
  user: User;
  reactions?: Record<string, string[]>;
  replyTo?: Message;
}

interface SocketMessage {
  type: 'join' | 'leave' | 'message' | 'userList' | 'typing' | 'stopTyping' | 'error' | 'reaction';
  data?: any;
  user?: User;
  message?: Message;
  users?: User[];
  error?: string;
  reaction?: {
    messageId: string;
    emoji: string;
    userId: string;
  };
}

export default function useWebSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [typingUsers, setTypingUsers] = useState<User[]>([]);
  const [error, setError] = useState<string>("");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  const { toast } = useToast();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttemptsRef = useRef(0);
  const maxReconnectAttempts = 5;

  const connect = useCallback(() => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        setError("");
        reconnectAttemptsRef.current = 0;
        
        // Load initial messages
        fetch('/api/messages')
          .then(res => res.json())
          .then(data => {
            if (Array.isArray(data)) {
              setMessages(data.map(msg => ({
                ...msg,
                createdAt: new Date(msg.createdAt)
              })));
            }
          })
          .catch(err => {
            console.error('Failed to load messages:', err);
          });
      };

      ws.onmessage = (event) => {
        try {
          const socketMessage: SocketMessage = JSON.parse(event.data);
          
          switch (socketMessage.type) {
            case 'join':
              if (socketMessage.user) {
                setCurrentUser(socketMessage.user);
                toast({
                  title: "Welcome!",
                  description: "You have successfully joined Shekhar Chat.",
                });
              }
              break;
              
            case 'message':
              if (socketMessage.message) {
                setMessages(prev => [...prev, {
                  ...socketMessage.message!,
                  createdAt: new Date(socketMessage.message!.createdAt)
                }]);
              }
              break;
              
            case 'userList':
              if (socketMessage.users) {
                setUsers(socketMessage.users);
              }
              if (socketMessage.data?.messages) {
                setMessages(socketMessage.data.messages.map((msg: any) => ({
                  ...msg,
                  createdAt: new Date(msg.createdAt)
                })));
              }
              break;
              
            case 'typing':
              if (socketMessage.user) {
                setTypingUsers(prev => {
                  if (!prev.find(u => u.id === socketMessage.user!.id)) {
                    return [...prev, socketMessage.user!];
                  }
                  return prev;
                });
              }
              break;
              
            case 'stopTyping':
              if (socketMessage.user) {
                setTypingUsers(prev => prev.filter(u => u.id !== socketMessage.user!.id));
              }
              break;
              
            case 'reaction':
              if (socketMessage.message) {
                setMessages(prev => prev.map(msg => 
                  msg.id === socketMessage.message!.id 
                    ? { ...socketMessage.message!, createdAt: new Date(socketMessage.message!.createdAt) }
                    : msg
                ));
              }
              break;
              
            case 'error':
              if (socketMessage.error) {
                setError(socketMessage.error);
                toast({
                  title: "Error",
                  description: socketMessage.error,
                  variant: "destructive",
                });
              }
              break;
          }
        } catch (err) {
          console.error('Failed to parse WebSocket message:', err);
        }
      };

      ws.onclose = (event) => {
        console.log('WebSocket disconnected:', event.code, event.reason);
        setIsConnected(false);
        setSocket(null);
        
        // Clear typing users on disconnect
        setTypingUsers([]);
        
        // Attempt to reconnect if not manually closed
        if (event.code !== 1000 && reconnectAttemptsRef.current < maxReconnectAttempts) {
          const timeout = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 10000);
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttemptsRef.current++;
            connect();
          }, timeout);
          
          toast({
            title: "Connection Lost",
            description: `Attempting to reconnect... (${reconnectAttemptsRef.current}/${maxReconnectAttempts})`,
            variant: "destructive",
          });
        } else if (reconnectAttemptsRef.current >= maxReconnectAttempts) {
          setError("Failed to connect to Shekhar Chat. Please refresh the page.");
          toast({
            title: "Connection Failed",
            description: "Unable to connect to Shekhar Chat. Please refresh the page.",
            variant: "destructive",
          });
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setError("Connection error occurred");
      };

      setSocket(ws);
    } catch (err) {
      console.error('Failed to create WebSocket connection:', err);
      setError("Failed to connect to Shekhar Chat");
    }
  }, [toast]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (socket) {
        socket.close(1000);
      }
    };
  }, [connect]);

  const joinChatroom = useCallback(async (displayName: string): Promise<boolean> => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      setError("Not connected to the server");
      return false;
    }

    try {
      socket.send(JSON.stringify({
        type: 'join',
        data: { displayName }
      }));
      return true;
    } catch (err) {
      console.error('Failed to join chatroom:', err);
      setError("Failed to join Shekhar Chat");
      return false;
    }
  }, [socket]);

  const sendMessage = useCallback((content: string, replyToId?: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      setError("Not connected to the server");
      return;
    }

    if (!content.trim()) return;

    try {
      socket.send(JSON.stringify({
        type: 'message',
        data: { 
          content: content.trim(),
          replyToId: replyToId || null
        }
      }));
    } catch (err) {
      console.error('Failed to send message:', err);
      setError("Failed to send message");
    }
  }, [socket]);

  const startTyping = useCallback(() => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    try {
      socket.send(JSON.stringify({
        type: 'typing'
      }));
    } catch (err) {
      console.error('Failed to send typing indicator:', err);
    }
  }, [socket]);

  const stopTyping = useCallback(() => {
    if (!socket || socket.readyState !== WebSocket.OPEN) return;

    try {
      socket.send(JSON.stringify({
        type: 'stopTyping'
      }));
    } catch (err) {
      console.error('Failed to stop typing indicator:', err);
    }
  }, [socket]);

  const clearError = useCallback(() => {
    setError("");
  }, []);

  const sendReaction = useCallback((messageId: string, emoji: string, action: 'add' | 'remove') => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      setError("Not connected to the server");
      return;
    }

    try {
      socket.send(JSON.stringify({
        type: 'reaction',
        data: { messageId, emoji, action }
      }));
    } catch (err) {
      console.error('Failed to send reaction:', err);
      setError("Failed to send reaction");
    }
  }, [socket]);

  return {
    messages,
    users,
    typingUsers,
    isConnected,
    error,
    currentUser,
    joinChatroom,
    sendMessage,
    startTyping,
    stopTyping,
    clearError,
    sendReaction
  };
}
