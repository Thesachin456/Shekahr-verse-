import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Send, Users, Settings, LogOut, Wifi, WifiOff, Terminal, X, Crown, Zap, Heart, MessageCircle, MoreHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  displayName: string;
  status: string;
  initials: string;
  avatarColor: string;
}

interface Message {
  id: string;
  content: string;
  type: 'message' | 'system';
  createdAt: Date;
  user: User;
  reactions?: Record<string, string[]>;
}

export default function Chatroom() {
  const [showJoinModal, setShowJoinModal] = useState(true);
  const [showSidebar, setShowSidebar] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState("");
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log("WebSocket connected");
      setIsConnected(true);
      setSocket(ws);
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'userList') {
        setUsers(data.users || []);
      } else if (data.type === 'message') {
        setMessages(prev => [...prev, data.message]);
      } else if (data.type === 'join') {
        setUsers(prev => [...prev, data.user]);
        if (data.message) {
          setMessages(prev => [...prev, data.message]);
        }
      } else if (data.type === 'leave') {
        setUsers(prev => prev.filter(u => u.id !== data.user?.id));
        if (data.message) {
          setMessages(prev => [...prev, data.message]);
        }
      } else if (data.type === 'error') {
        setError(data.error || "An error occurred");
        toast({
          title: "Error",
          description: data.error || "An error occurred",
          variant: "destructive",
        });
      }
    };
    
    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setIsConnected(false);
    };
    
    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setError("Connection error occurred");
    };
    
    return () => {
      ws.close();
    };
  }, [toast]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || !socket || socket.readyState !== WebSocket.OPEN) return;
    
    socket.send(JSON.stringify({
      type: 'join',
      data: { displayName: displayName.trim() }
    }));
    
    setShowJoinModal(false);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !socket || socket.readyState !== WebSocket.OPEN) return;
    
    socket.send(JSON.stringify({
      type: 'message',
      data: { content: message.trim() }
    }));
    
    setMessage("");
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (showJoinModal) {
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div className="cyber-modal max-w-md w-full p-8 relative">
          <div className="absolute inset-0 bg-gradient-to-br from-[var(--neon-blue)]/10 to-[var(--neon-purple)]/10 rounded-2xl"></div>
          
          <div className="relative z-10">
            <div className="text-center mb-8">
              <Terminal className="w-12 h-12 mx-auto mb-4 neon-blue" />
              <h1 className="shkeharverse-logo text-3xl mb-2">ShkeharVerse</h1>
              <p className="text-[var(--text-secondary)] text-sm">ENTER THE DIGITAL REALM</p>
            </div>

            <form onSubmit={handleJoin} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="displayName" className="text-sm font-medium neon-cyan">CODENAME</label>
                <Input
                  id="displayName"
                  type="text"
                  placeholder="Enter your handle..."
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="cyber-input w-full"
                  style={{ fontSize: '16px' }}
                  maxLength={30}
                  required
                />
                <p className="text-xs text-[var(--text-muted)]">Choose your identity in the verse</p>
              </div>

              {error && (
                <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg">
                  <p className="text-red-400 text-sm">{error}</p>
                </div>
              )}

              <Button type="submit" className="cyber-button w-full" disabled={!displayName.trim()}>
                JACK IN
              </Button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col lg:flex-row relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-[var(--neon-blue)]/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-[var(--neon-purple)]/5 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-[var(--neon-cyan)]/5 rounded-full blur-2xl animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      {/* User Sidebar */}
      {showSidebar && (
        <>
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden" onClick={() => setShowSidebar(false)} />
          
          <div className="fixed top-0 right-0 h-full w-full max-w-sm glass-panel border-l border-[var(--neon-blue)]/20 z-50 lg:relative lg:w-64 lg:max-w-none">
            <div className="p-4 border-b border-[var(--neon-blue)]/20 flex items-center justify-between">
              <h2 className="font-semibold neon-cyan text-sm tracking-wide">ONLINE OPERATORS</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowSidebar(false)} className="lg:hidden cyber-button p-1">
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="px-4 py-2 text-xs text-[var(--text-muted)] border-b border-[var(--neon-blue)]/10">
              <span className="neon-green">{users.length}</span> users connected to the verse
            </div>

            <div className="flex-1 overflow-y-auto cyber-scroll p-2">
              <div className="space-y-1">
                {users.map((user) => (
                  <div key={user.id} className="p-3 rounded-lg transition-all duration-200 relative group cursor-pointer hover:bg-[var(--bg-glass)] hover:border hover:border-[var(--neon-blue)]/20">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={`user-avatar ${user.avatarColor} text-xs`}>
                          <span>{user.initials}</span>
                        </div>
                        <div className="online-indicator"></div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-[var(--text-primary)] text-sm truncate">{user.displayName}</p>
                          {currentUser?.id === user.id && <Crown className="w-3 h-3 neon-blue" />}
                        </div>
                        <p className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                          <Zap className="w-3 h-3 neon-green" />
                          ACTIVE
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative z-10">
        {/* Chat Header */}
        <header className="glass-panel border-b border-[var(--neon-blue)]/20 p-4 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-4">
            <div className="shkeharverse-logo glitch">ShkeharVerse</div>
            <div className="flex items-center gap-2 text-sm">
              {isConnected ? (
                <>
                  <Wifi className="w-4 h-4 neon-green" />
                  <span className="neon-green">ONLINE</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 text-red-400" />
                  <span className="text-red-400">OFFLINE</span>
                </>
              )}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4 text-sm text-[var(--text-secondary)]">
            <div className="cyber-input px-3 py-1 text-xs">
              <span className="neon-cyan">{users.length}</span> USERS ONLINE
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowSidebar(!showSidebar)} className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px]">
              <Users className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">USERS</span>
            </Button>
            
            <Button variant="ghost" size="sm" className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px] hidden sm:flex">
              <Settings className="w-4 h-4" />
            </Button>
            
            <Button variant="ghost" size="sm" className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px] hidden sm:flex">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </header>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-2 cyber-scroll bg-gradient-to-b from-transparent to-[var(--bg-secondary)]/20">
          {messages.map((msg) => {
            if (msg.type === 'system') {
              return (
                <div key={msg.id} className="flex justify-center my-4">
                  <div className="bg-[var(--bg-glass)] text-[var(--text-muted)] text-sm px-4 py-2 rounded-full border border-[var(--neon-blue)]/20">
                    {msg.content}
                  </div>
                </div>
              );
            }

            const isOwn = currentUser && msg.user.id === currentUser.id;
            
            return (
              <div key={msg.id} className={`group flex items-start space-x-3 relative mb-6 floating ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}>
                <div className={`user-avatar ${msg.user.avatarColor}`}>
                  <span>{msg.user.initials}</span>
                </div>
                <div className={`flex-1 ${isOwn ? 'flex flex-col items-end' : ''}`}>
                  <div className={`flex items-center space-x-2 mb-2 ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <span className="text-sm font-medium neon-cyan">{msg.user.displayName}</span>
                    <span className="text-xs text-[var(--text-muted)]">{formatTime(msg.createdAt)}</span>
                  </div>
                  
                  <div className={`message-bubble ${isOwn ? 'own' : 'other'} relative`}>
                    <p className="text-sm text-[var(--text-primary)]">{msg.content}</p>
                    
                    {/* Message actions */}
                    <div className={`message-actions md:absolute md:-top-3 static mt-2 flex justify-center md:justify-start md:opacity-0 md:group-hover:opacity-100 opacity-100 transition-opacity duration-200 gap-1 ${isOwn ? 'md:-left-16' : 'md:-right-16'}`}>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
                        onClick={() => {
                          if (socket && socket.readyState === WebSocket.OPEN) {
                            socket.send(JSON.stringify({
                              type: 'reaction',
                              data: { messageId: msg.id, emoji: '❤️', action: 'add' }
                            }));
                          }
                        }}
                      >
                        ❤️
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
                        onClick={() => {
                          if (socket && socket.readyState === WebSocket.OPEN) {
                            socket.send(JSON.stringify({
                              type: 'reaction',
                              data: { messageId: msg.id, emoji: '👍', action: 'add' }
                            }));
                          }
                        }}
                      >
                        👍
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
                        onClick={() => {
                          if (socket && socket.readyState === WebSocket.OPEN) {
                            socket.send(JSON.stringify({
                              type: 'reaction',
                              data: { messageId: msg.id, emoji: '😂', action: 'add' }
                            }));
                          }
                        }}
                      >
                        😂
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="glass-panel border-t border-[var(--neon-blue)]/20 relative z-10">
          <div className="p-4 md:p-6">
            <form onSubmit={handleSendMessage} className="flex items-end space-x-2 md:space-x-4">
              <div className="flex-1 relative">
                <Textarea
                  placeholder="Transmit your signal..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e);
                    }
                  }}
                  className="cyber-input resize-none min-h-[52px] max-h-[120px] pr-16 text-[var(--text-primary)] placeholder:text-[var(--text-muted)] w-full"
                  style={{ fontSize: '16px' }}
                  rows={1}
                />
                
                <div className="absolute bottom-3 right-4 text-xs text-[var(--text-muted)] pointer-events-none">
                  <span className={`${message.length > 500 ? "text-red-400" : "neon-cyan"}`}>{message.length}</span>/500
                </div>
              </div>
              
              <Button type="submit" className="cyber-button h-[52px] px-4 md:px-6 min-w-[52px]" disabled={!message.trim()}>
                <Send className="h-5 w-5" />
              </Button>
            </form>

            {error && (
              <div className="mt-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg backdrop-filter backdrop-blur-sm">
                <div className="flex items-center">
                  <span className="text-sm text-red-400">{error}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile User List Button */}
      <Button onClick={() => setShowSidebar(!showSidebar)} className="lg:hidden fixed bottom-24 right-6 cyber-button z-30 floating" size="icon">
        <Users className="w-5 h-5" />
      </Button>
    </div>
  );
}