import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Terminal } from "lucide-react";

interface JoinModalProps {
  onJoin: (displayName: string) => void;
  isLoading?: boolean;
  error?: string;
}

export default function JoinModal({ onJoin, isLoading, error }: JoinModalProps) {
  const [displayName, setDisplayName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (displayName.trim()) {
      onJoin(displayName.trim());
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="cyber-modal max-w-md w-full p-8 relative">
        {/* Animated background elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-[var(--neon-blue)]/10 to-[var(--neon-purple)]/10 rounded-2xl"></div>
        
        <div className="relative z-10">
          {/* Header */}
          <div className="text-center mb-8">
            <Terminal className="w-12 h-12 mx-auto mb-4 neon-blue" />
            <h1 className="shkeharverse-logo text-3xl mb-2">ShkeharVerse</h1>
            <p className="text-[var(--text-secondary)] text-sm">
              ENTER THE DIGITAL REALM
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="displayName" className="text-sm font-medium neon-cyan">
                CODENAME
              </Label>
              <Input
                id="displayName"
                type="text"
                placeholder="Enter your handle..."
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="cyber-input w-full"
                style={{ fontSize: '16px' }} // Prevents zoom on iOS
                disabled={isLoading}
                maxLength={30}
                required
              />
              <p className="text-xs text-[var(--text-muted)]">
                Choose your identity in the verse
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg">
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              className="cyber-button w-full"
              disabled={isLoading || !displayName.trim()}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  CONNECTING...
                </>
              ) : (
                "JACK IN"
              )}
            </Button>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-xs text-[var(--text-muted)]">
              Welcome to the future of communication
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}