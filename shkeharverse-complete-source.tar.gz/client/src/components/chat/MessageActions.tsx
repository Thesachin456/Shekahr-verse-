import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

interface MessageActionsProps {
  messageId: string;
  onReply: (messageId: string) => void;
  onReaction: (messageId: string, emoji: string, action: 'add' | 'remove') => void;
  className?: string;
}

export default function MessageActions({ 
  messageId, 
  onReply, 
  onReaction, 
  className 
}: MessageActionsProps) {
  const [showActions, setShowActions] = useState(false);

  return (
    <div className={cn(
      "md:opacity-0 md:group-hover:opacity-100 opacity-100 transition-opacity duration-200 flex items-center gap-1",
      className
    )}>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onReaction(messageId, '❤️', 'add')}
        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
      >
        <Heart className="w-4 h-4 md:w-3 md:h-3" />
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onReply(messageId)}
        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
      >
        <MessageCircle className="w-4 h-4 md:w-3 md:h-3" />
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        className="cyber-button p-1 h-8 w-8 md:h-7 md:w-7 min-h-[44px] md:min-h-[28px] min-w-[44px] md:min-w-[28px]"
      >
        <MoreHorizontal className="w-4 h-4 md:w-3 md:h-3" />
      </Button>
    </div>
  );
}