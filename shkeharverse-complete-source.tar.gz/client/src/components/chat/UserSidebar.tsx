import { X, Crown, Zap, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

interface User {
  id: string;
  displayName: string;
  initials: string;
  avatarColor: string;
  status?: string;
}

interface UserSidebarProps {
  users: User[];
  currentUser: User | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function UserSidebar({ users, currentUser, isOpen, onClose }: UserSidebarProps) {
  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 right-0 h-full w-full max-w-sm glass-panel border-l border-[var(--neon-blue)]/20 z-50 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        lg:relative lg:translate-x-0 lg:w-64 lg:max-w-none
      `}>
        {/* Header */}
        <div className="p-4 border-b border-[var(--neon-blue)]/20 flex items-center justify-between">
          <h2 className="font-semibold neon-cyan text-sm tracking-wide">
            ONLINE OPERATORS
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="lg:hidden cyber-button p-1"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* User count */}
        <div className="px-4 py-2 text-xs text-[var(--text-muted)] border-b border-[var(--neon-blue)]/10">
          <span className="neon-green">{users.length}</span> users connected to the verse
        </div>

        {/* Users list */}
        <div className="flex-1 overflow-y-auto cyber-scroll p-2">
          <div className="space-y-1">
            {users.map((user) => {
              const isCurrentUser = currentUser?.id === user.id;
              
              return (
                <div
                  key={user.id}
                  className={`
                    p-3 rounded-lg transition-all duration-200 relative group cursor-pointer
                    ${isCurrentUser 
                      ? 'bg-gradient-to-r from-[var(--neon-blue)]/20 to-[var(--neon-purple)]/20 border border-[var(--neon-blue)]/30' 
                      : 'hover:bg-[var(--bg-glass)] hover:border hover:border-[var(--neon-blue)]/20'
                    }
                  `}
                >
                  <div className="flex items-center gap-3">
                    {/* Avatar */}
                    <div className="relative">
                      <div className={`user-avatar ${user.avatarColor} text-xs`}>
                        <span>{user.initials}</span>
                      </div>
                      <div className="online-indicator"></div>
                    </div>

                    {/* User info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-[var(--text-primary)] text-sm truncate">
                          {user.displayName}
                        </p>
                        {isCurrentUser && (
                          <Crown className="w-3 h-3 neon-blue" />
                        )}
                      </div>
                      <p className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                        <Zap className="w-3 h-3 neon-green" />
                        ACTIVE
                      </p>
                    </div>

                    {/* Status indicator */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-2 h-2 bg-[var(--neon-green)] rounded-full animate-pulse"></div>
                    </div>
                  </div>

                  {/* Glow effect on hover */}
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--neon-blue)]/5 to-[var(--neon-purple)]/5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                </div>
              );
            })}
          </div>

          {/* Empty state */}
          {users.length === 0 && (
            <div className="text-center py-8">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-[var(--bg-glass)] flex items-center justify-center">
                <Users className="w-6 h-6 text-[var(--text-muted)]" />
              </div>
              <p className="text-[var(--text-muted)] text-sm">
                No operators online
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[var(--neon-blue)]/20">
          <div className="text-xs text-[var(--text-muted)] text-center">
            Connected to ShkeharVerse
          </div>
        </div>
      </div>
    </>
  );
}