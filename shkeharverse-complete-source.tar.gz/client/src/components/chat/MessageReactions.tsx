import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface MessageReactionsProps {
  messageId: string;
  reactions: Record<string, string[]>;
  currentUserId?: string;
  onAddReaction: (messageId: string, emoji: string) => void;
  onRemoveReaction: (messageId: string, emoji: string) => void;
}

const commonEmojis = ['❤️', '😂', '👍', '👎', '😮', '😢', '🔥', '🎉'];

export default function MessageReactions({
  messageId,
  reactions,
  currentUserId,
  onAddReaction,
  onRemoveReaction
}: MessageReactionsProps) {
  const hasReactions = Object.keys(reactions).length > 0;

  const handleReactionClick = (emoji: string) => {
    if (!currentUserId) return;
    
    const userReacted = reactions[emoji]?.includes(currentUserId);
    if (userReacted) {
      onRemoveReaction(messageId, emoji);
    } else {
      onAddReaction(messageId, emoji);
    }
  };

  const handleAddReaction = (emoji: string) => {
    onAddReaction(messageId, emoji);
  };

  if (!hasReactions) {
    return null;
  }

  return (
    <div className="flex flex-wrap gap-1 mt-2">
      {Object.entries(reactions).map(([emoji, userIds]) => {
        const count = userIds.length;
        const userReacted = currentUserId ? userIds.includes(currentUserId) : false;
        
        if (count === 0) return null;
        
        return (
          <Button
            key={emoji}
            variant="ghost"
            size="sm"
            onClick={() => handleReactionClick(emoji)}
            className={`reaction-button ${userReacted ? 'active' : ''} h-7 px-2 text-xs`}
          >
            <span className="mr-1">{emoji}</span>
            <span className="text-[var(--text-muted)]">{count}</span>
          </Button>
        );
      })}
      
      {/* Add reaction button */}
      <div className="relative group">
        <Button
          variant="ghost"
          size="sm"
          className="reaction-button h-7 w-7 p-0"
        >
          <Plus className="w-3 h-3" />
        </Button>
        
        {/* Emoji picker tooltip */}
        <div className="absolute bottom-full left-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none group-hover:pointer-events-auto z-50">
          <div className="glass-panel p-2 rounded-lg border border-[var(--neon-blue)]/20 min-w-max">
            <div className="flex gap-1">
              {commonEmojis.map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleAddReaction(emoji)}
                  className="h-8 w-8 p-0 hover:bg-[var(--neon-blue)]/10 transition-colors"
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}