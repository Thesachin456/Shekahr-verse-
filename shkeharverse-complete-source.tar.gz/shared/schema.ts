import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  avatar: text("avatar"),
  status: text("status").notNull().default("online"), // online, away, offline
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  type: text("type").notNull().default("message"), // message, system
  replyToId: varchar("reply_to_id").references(() => messages.id),
  reactions: json("reactions").$type<Record<string, string[]>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one, many }) => ({
  user: one(users, {
    fields: [messages.userId],
    references: [users.id],
  }),
  replyTo: one(messages, {
    fields: [messages.replyToId],
    references: [messages.id],
    relationName: "replies",
  }),
  replies: many(messages, {
    relationName: "replies",
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  displayName: true,
}).extend({
  displayName: z.string().min(2).max(50).regex(/^[a-zA-Z0-9\s]+$/, "Only letters, numbers and spaces allowed"),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  replyToId: true,
}).extend({
  content: z.string().min(1).max(500),
  replyToId: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type MessageWithUser = Message & {
  user: User;
  replyTo?: MessageWithUser;
};

export type SocketMessage = {
  type: 'join' | 'leave' | 'message' | 'userList' | 'typing' | 'stopTyping' | 'error' | 'reaction' | 'reply';
  data?: any;
  user?: User;
  message?: MessageWithUser;
  users?: User[];
  error?: string;
  reaction?: {
    messageId: string;
    emoji: string;
    userId: string;
  };
};
