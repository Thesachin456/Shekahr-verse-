import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema, type SocketMessage, type User } from "@shared/schema";
import { z } from "zod";

interface WebSocketClient extends WebSocket {
  userId?: string;
  isAlive?: boolean;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server setup
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws'
  });

  const clients = new Set<WebSocketClient>();

  // Broadcast to all connected clients
  function broadcast(message: SocketMessage, excludeClient?: WebSocketClient) {
    clients.forEach(client => {
      if (client !== excludeClient && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  // Send message to specific client
  function sendToClient(client: WebSocketClient, message: SocketMessage) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }

  // Get user initials for avatar
  function getUserInitials(displayName: string): string {
    return displayName
      .split(' ')
      .map(name => name.charAt(0).toUpperCase())
      .join('')
      .substring(0, 2);
  }

  // Get avatar color based on display name
  function getAvatarColor(displayName: string): string {
    const colors = [
      'bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-orange-500', 
      'bg-pink-500', 'bg-red-500', 'bg-indigo-500', 'bg-yellow-500'
    ];
    const index = displayName.length % colors.length;
    return colors[index];
  }

  wss.on('connection', (ws: WebSocketClient) => {
    clients.add(ws);
    ws.isAlive = true;

    // Send recent messages to new connection
    storage.getRecentMessages().then(messages => {
      sendToClient(ws, {
        type: 'userList',
        data: {
          messages: messages.map(msg => ({
            ...msg,
            user: {
              ...msg.user,
              initials: getUserInitials(msg.user.displayName),
              avatarColor: getAvatarColor(msg.user.displayName)
            }
          }))
        }
      });
    });

    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('message', async (data) => {
      try {
        const socketMessage: SocketMessage = JSON.parse(data.toString());

        switch (socketMessage.type) {
          case 'join': {
            try {
              const userData = insertUserSchema.parse(socketMessage.data);
              
              // Check if display name is already taken
              const existingUser = await storage.getUserByDisplayName(userData.displayName);
              if (existingUser) {
                sendToClient(ws, {
                  type: 'error',
                  error: 'Display name is already taken. Please choose a different name.'
                });
                return;
              }

              // Create new user
              const user = await storage.createUser(userData);
              ws.userId = user.id;

              // Add avatar properties
              const userWithAvatar = {
                ...user,
                initials: getUserInitials(user.displayName),
                avatarColor: getAvatarColor(user.displayName)
              };

              // Create system message
              await storage.createSystemMessage(`${user.displayName} joined the chat`);

              // Send success response to joining user
              sendToClient(ws, {
                type: 'join',
                user: userWithAvatar
              });

              // Broadcast user list update
              const activeUsers = await storage.getActiveUsers();
              const usersWithAvatars = activeUsers.map(u => ({
                ...u,
                initials: getUserInitials(u.displayName),
                avatarColor: getAvatarColor(u.displayName)
              }));

              broadcast({
                type: 'userList',
                users: usersWithAvatars
              });

              // Broadcast system message
              const recentMessages = await storage.getRecentMessages(1);
              if (recentMessages.length > 0) {
                broadcast({
                  type: 'message',
                  message: {
                    ...recentMessages[0],
                    user: {
                      ...recentMessages[0].user,
                      initials: getUserInitials(recentMessages[0].user.displayName),
                      avatarColor: getAvatarColor(recentMessages[0].user.displayName)
                    }
                  }
                });
              }

            } catch (error) {
              if (error instanceof z.ZodError) {
                sendToClient(ws, {
                  type: 'error',
                  error: error.errors.map(e => e.message).join(', ')
                });
              } else {
                sendToClient(ws, {
                  type: 'error',
                  error: 'Failed to join chatroom'
                });
              }
            }
            break;
          }

          case 'message': {
            if (!ws.userId) {
              sendToClient(ws, {
                type: 'error',
                error: 'You must join the chatroom first'
              });
              return;
            }

            try {
              const messageData = insertMessageSchema.parse(socketMessage.data);
              const message = await storage.createMessage(ws.userId, messageData);
              
              // Add avatar properties
              const messageWithAvatar = {
                ...message,
                user: {
                  ...message.user,
                  initials: getUserInitials(message.user.displayName),
                  avatarColor: getAvatarColor(message.user.displayName)
                }
              };

              // Broadcast message to all clients
              broadcast({
                type: 'message',
                message: messageWithAvatar
              });

            } catch (error) {
              if (error instanceof z.ZodError) {
                sendToClient(ws, {
                  type: 'error',
                  error: error.errors.map(e => e.message).join(', ')
                });
              } else {
                sendToClient(ws, {
                  type: 'error',
                  error: 'Failed to send message'
                });
              }
            }
            break;
          }

          case 'typing': {
            if (ws.userId) {
              const user = await storage.getUser(ws.userId);
              if (user) {
                broadcast({
                  type: 'typing',
                  user: {
                    ...user,
                    initials: getUserInitials(user.displayName),
                    avatarColor: getAvatarColor(user.displayName)
                  }
                }, ws);
              }
            }
            break;
          }

          case 'stopTyping': {
            if (ws.userId) {
              const user = await storage.getUser(ws.userId);
              if (user) {
                broadcast({
                  type: 'stopTyping',
                  user: {
                    ...user,
                    initials: getUserInitials(user.displayName),
                    avatarColor: getAvatarColor(user.displayName)
                  }
                }, ws);
              }
            }
            break;
          }

          case 'reaction': {
            if (!ws.userId) {
              sendToClient(ws, {
                type: 'error',
                error: 'You must join the chatroom first'
              });
              return;
            }

            try {
              const { messageId, emoji, action } = socketMessage.data;
              
              let updatedMessage;
              if (action === 'add') {
                updatedMessage = await storage.addReaction(messageId, emoji, ws.userId);
              } else if (action === 'remove') {
                updatedMessage = await storage.removeReaction(messageId, emoji, ws.userId);
              }

              if (updatedMessage) {
                // Add avatar properties
                const messageWithAvatar = {
                  ...updatedMessage,
                  user: {
                    ...updatedMessage.user,
                    initials: getUserInitials(updatedMessage.user.displayName),
                    avatarColor: getAvatarColor(updatedMessage.user.displayName)
                  }
                };

                // Broadcast reaction update to all clients
                broadcast({
                  type: 'reaction',
                  message: messageWithAvatar,
                  reaction: {
                    messageId,
                    emoji,
                    userId: ws.userId
                  }
                });
              }

            } catch (error) {
              sendToClient(ws, {
                type: 'error',
                error: 'Failed to update reaction'
              });
            }
            break;
          }
        }
      } catch (error) {
        sendToClient(ws, {
          type: 'error',
          error: 'Invalid message format'
        });
      }
    });

    ws.on('close', async () => {
      clients.delete(ws);
      
      if (ws.userId) {
        const user = await storage.getUser(ws.userId);
        if (user) {
          // Create system message
          await storage.createSystemMessage(`${user.displayName} left the chat`);
          
          // Remove user
          await storage.removeUser(ws.userId);
          
          // Broadcast updated user list
          const activeUsers = await storage.getActiveUsers();
          const usersWithAvatars = activeUsers.map(u => ({
            ...u,
            initials: getUserInitials(u.displayName),
            avatarColor: getAvatarColor(u.displayName)
          }));

          broadcast({
            type: 'userList',
            users: usersWithAvatars
          });

          // Broadcast system message
          const recentMessages = await storage.getRecentMessages(1);
          if (recentMessages.length > 0) {
            broadcast({
              type: 'message',
              message: {
                ...recentMessages[0],
                user: {
                  ...recentMessages[0].user,
                  initials: getUserInitials(recentMessages[0].user.displayName),
                  avatarColor: getAvatarColor(recentMessages[0].user.displayName)
                }
              }
            });
          }
        }
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Ping clients periodically to keep connections alive
  const interval = setInterval(() => {
    wss.clients.forEach((ws: WebSocketClient) => {
      if (ws.isAlive === false) {
        ws.terminate();
        clients.delete(ws);
        return;
      }
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });

  // REST API endpoints for initial data
  app.get('/api/messages', async (req, res) => {
    try {
      const messages = await storage.getRecentMessages();
      const messagesWithAvatars = messages.map(msg => ({
        ...msg,
        user: {
          ...msg.user,
          initials: getUserInitials(msg.user.displayName),
          avatarColor: getAvatarColor(msg.user.displayName)
        }
      }));
      res.json(messagesWithAvatars);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  app.get('/api/users', async (req, res) => {
    try {
      const users = await storage.getActiveUsers();
      const usersWithAvatars = users.map(user => ({
        ...user,
        initials: getUserInitials(user.displayName),
        avatarColor: getAvatarColor(user.displayName)
      }));
      res.json(usersWithAvatars);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  return httpServer;
}
