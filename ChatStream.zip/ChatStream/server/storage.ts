import { users, messages, type User, type InsertUser, type Message, type InsertMessage, type MessageWithUser } from "@shared/schema";
import { db } from "./db";
import { eq, desc, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByDisplayName(displayName: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: string, status: "online" | "away" | "offline"): Promise<User | undefined>;
  getActiveUsers(): Promise<User[]>;
  removeUser(id: string): Promise<void>;
  
  // Message operations
  createMessage(userId: string, message: InsertMessage): Promise<MessageWithUser>;
  getRecentMessages(limit?: number): Promise<MessageWithUser[]>;
  createSystemMessage(content: string): Promise<MessageWithUser>;
  addReaction(messageId: string, emoji: string, userId: string): Promise<MessageWithUser | undefined>;
  removeReaction(messageId: string, emoji: string, userId: string): Promise<MessageWithUser | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByDisplayName(displayName: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.displayName, displayName));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const username = insertUser.displayName.toLowerCase().replace(/\s+/g, '_');
    
    const [user] = await db
      .insert(users)
      .values({
        username,
        displayName: insertUser.displayName,
        avatar: null,
        status: "online",
      })
      .returning();
    return user;
  }

  async updateUserStatus(id: string, status: "online" | "away" | "offline"): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ status })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getActiveUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.status, "online"));
  }

  async removeUser(id: string): Promise<void> {
    // First update user status to offline instead of deleting to maintain message references
    await db.update(users).set({ status: "offline" }).where(eq(users.id, id));
  }

  async createMessage(userId: string, insertMessage: InsertMessage): Promise<MessageWithUser> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const [message] = await db
      .insert(messages)
      .values({
        userId,
        content: insertMessage.content,
        type: "message",
        replyToId: insertMessage.replyToId || null,
        reactions: {},
      })
      .returning();

    // Get reply message if exists
    let replyTo: MessageWithUser | undefined;
    if (message.replyToId) {
      const replyResult = await db
        .select({
          message: messages,
          user: users,
        })
        .from(messages)
        .innerJoin(users, eq(messages.userId, users.id))
        .where(eq(messages.id, message.replyToId))
        .limit(1);

      if (replyResult.length > 0) {
        replyTo = {
          ...replyResult[0].message,
          user: replyResult[0].user,
        };
      }
    }

    return {
      ...message,
      user,
      replyTo,
    };
  }

  async getRecentMessages(limit = 50): Promise<MessageWithUser[]> {
    const result = await db
      .select({
        message: messages,
        user: users,
      })
      .from(messages)
      .innerJoin(users, eq(messages.userId, users.id))
      .orderBy(desc(messages.createdAt))
      .limit(limit);

    // Get all reply messages for the messages we found
    const replyToIds = result.map(r => r.message.replyToId).filter(Boolean) as string[];
    
    let replyMessages: Record<string, MessageWithUser> = {};
    if (replyToIds.length > 0) {
      const replyResult = await db
        .select({
          message: messages,
          user: users,
        })
        .from(messages)
        .innerJoin(users, eq(messages.userId, users.id))
        .where(inArray(messages.id, replyToIds));

      for (const reply of replyResult) {
        replyMessages[reply.message.id] = {
          ...reply.message,
          user: reply.user,
        };
      }
    }

    return result.map(({ message, user }) => ({
      ...message,
      user,
      replyTo: message.replyToId ? replyMessages[message.replyToId] : undefined,
    })).reverse(); // Reverse to get chronological order
  }

  async createSystemMessage(content: string): Promise<MessageWithUser> {
    // Check if system user exists, create if not
    let systemUser = await this.getUser("system");
    if (!systemUser) {
      const [newSystemUser] = await db
        .insert(users)
        .values({
          id: "system",
          username: "system",
          displayName: "System",
          avatar: null,
          status: "online",
        })
        .returning();
      systemUser = newSystemUser;
    }

    const [message] = await db
      .insert(messages)
      .values({
        userId: "system",
        content,
        type: "system",
        reactions: {},
      })
      .returning();

    return {
      ...message,
      user: systemUser,
    };
  }

  async addReaction(messageId: string, emoji: string, userId: string): Promise<MessageWithUser | undefined> {
    // Get current message
    const [currentMessage] = await db.select().from(messages).where(eq(messages.id, messageId));
    if (!currentMessage) return undefined;

    const reactions = currentMessage.reactions as Record<string, string[]> || {};
    
    // Add user to emoji reactions if not already there
    if (!reactions[emoji]) {
      reactions[emoji] = [];
    }
    if (!reactions[emoji].includes(userId)) {
      reactions[emoji].push(userId);
    }

    // Update message with new reactions
    const [updatedMessage] = await db
      .update(messages)
      .set({ reactions })
      .where(eq(messages.id, messageId))
      .returning();

    // Get user info
    const user = await this.getUser(updatedMessage.userId);
    if (!user) return undefined;

    return {
      ...updatedMessage,
      user,
    };
  }

  async removeReaction(messageId: string, emoji: string, userId: string): Promise<MessageWithUser | undefined> {
    // Get current message
    const [currentMessage] = await db.select().from(messages).where(eq(messages.id, messageId));
    if (!currentMessage) return undefined;

    const reactions = currentMessage.reactions as Record<string, string[]> || {};
    
    // Remove user from emoji reactions
    if (reactions[emoji]) {
      reactions[emoji] = reactions[emoji].filter(id => id !== userId);
      // Remove emoji key if no users left
      if (reactions[emoji].length === 0) {
        delete reactions[emoji];
      }
    }

    // Update message with new reactions
    const [updatedMessage] = await db
      .update(messages)
      .set({ reactions })
      .where(eq(messages.id, messageId))
      .returning();

    // Get user info
    const user = await this.getUser(updatedMessage.userId);
    if (!user) return undefined;

    return {
      ...updatedMessage,
      user,
    };
  }
}

export const storage = new DatabaseStorage();
