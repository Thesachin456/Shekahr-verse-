import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Send, Users, Settings, LogOut, Wifi, WifiOff, Terminal, X, Crown, Zap, Heart, MessageCircle, MoreHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Chatroom() {
  const [showJoinModal, setShowJoinModal] = useState(true);
  const [showSidebar, setShowSidebar] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [replyingTo, setReplyingTo] = useState<any>(null);

  const {
    messages,
    users,
    isConnected,
    typingUsers,
    error,
    joinChatroom,
    sendMessage,
    startTyping,
    stopTyping,
    clearError,
    sendReaction
  } = useWebSocket();

  const handleJoin = async (displayName: string) => {
    const success = await joinChatroom(displayName);
    if (success) {
      setShowJoinModal(false);
    }
  };

  const handleSendMessage = (content: string, replyToId?: string) => {
    sendMessage(content, replyToId);
  };

  const handleReply = (messageId: string) => {
    const message = messages.find((m: any) => m.id === messageId);
    if (message) {
      setReplyingTo(message);
    }
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  const handleReaction = (messageId: string, emoji: string, action: 'add' | 'remove') => {
    sendReaction(messageId, emoji, action);
  };

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        clearError();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, clearError]);

  // Set current user when joining
  useEffect(() => {
    if (users.length > 0 && !currentUser) {
      // This would be set properly in a real app with authentication
      setCurrentUser(users[0]);
    }
  }, [users, currentUser]);

  return (
    <div className="h-screen flex flex-col lg:flex-row relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-[var(--neon-blue)]/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-[var(--neon-purple)]/5 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-[var(--neon-cyan)]/5 rounded-full blur-2xl animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      {/* Join Modal */}
      {showJoinModal && (
        <JoinModal 
          onJoin={handleJoin}
          error={error}
        />
      )}

      {/* User Sidebar */}
      <UserSidebar 
        users={users}
        currentUser={currentUser}
        isOpen={showSidebar}
        onClose={() => setShowSidebar(false)}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative z-10">
        {/* Chat Header */}
        <ChatHeader
          isConnected={isConnected}
          activeUserCount={users.length}
          onToggleSidebar={toggleSidebar}
        />

        {/* Message List */}
        <MessageList
          messages={messages}
          currentUser={currentUser}
          typingUsers={typingUsers}
          onReply={handleReply}
          onReaction={handleReaction}
        />

        {/* Message Input */}
        <MessageInput
          onSendMessage={handleSendMessage}
          onStartTyping={startTyping}
          onStopTyping={stopTyping}
          error={error}
          replyingTo={replyingTo}
          onCancelReply={handleCancelReply}
        />
      </div>

      {/* Mobile User List Button */}
      <Button
        onClick={toggleSidebar}
        className="lg:hidden fixed bottom-24 right-6 cyber-button z-30 floating"
        size="icon"
      >
        <Users className="w-5 h-5" />
      </Button>
    </div>
  );
}
