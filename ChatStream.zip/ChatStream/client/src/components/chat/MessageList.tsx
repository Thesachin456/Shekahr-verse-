import { useEffect, useRef } from "react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import MessageReactions from "./MessageReactions";
import MessageActions from "./MessageActions";

interface User {
  id: string;
  displayName: string;
  initials: string;
  avatarColor: string;
}

interface Message {
  id: string;
  content: string;
  type: 'message' | 'system';
  createdAt: Date;
  user: User;
  reactions?: Record<string, string[]>;
  replyTo?: Message;
}

interface MessageListProps {
  messages: Message[];
  currentUser: User | null;
  typingUsers: User[];
  onReply: (messageId: string) => void;
  onReaction: (messageId: string, emoji: string, action: 'add' | 'remove') => void;
}

export default function MessageList({ messages, currentUser, typingUsers, onReply, onReaction }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, typingUsers]);

  const formatTime = (date: Date) => {
    return format(new Date(date), 'h:mm a');
  };

  const isOwnMessage = (message: Message) => {
    return currentUser && message.user.id === currentUser.id;
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-2 cyber-scroll bg-gradient-to-b from-transparent to-[var(--bg-secondary)]/20">
      {messages.map((message) => {
        if (message.type === 'system') {
          return (
            <div key={message.id} className="flex justify-center">
              <div className="bg-gray-100 text-[#757575] text-sm px-3 py-1 rounded-full">
                {message.content}
              </div>
            </div>
          );
        }

        const isOwn = isOwnMessage(message);

        return (
          <div key={message.id} className={cn(
            "group flex items-start space-x-3 relative mb-6 floating",
            isOwn && "flex-row-reverse space-x-reverse"
          )}>
            <div className={cn("user-avatar", message.user.avatarColor)}>
              <span>{message.user.initials}</span>
            </div>
            <div className={cn("flex-1", isOwn && "flex flex-col items-end")}>
              <div className={cn(
                "flex items-center space-x-2 mb-2",
                isOwn && "flex-row-reverse space-x-reverse"
              )}>
                <span className="text-sm font-medium neon-cyan">
                  {message.user.displayName}
                </span>
                <span className="text-xs text-[var(--text-muted)]">
                  {formatTime(message.createdAt)}
                </span>
              </div>
              
              {/* Reply indicator */}
              {message.replyTo && (
                <div className="reply-indicator mb-3 max-w-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className={cn("w-4 h-4 rounded-full flex items-center justify-center text-white text-xs", message.replyTo.user.avatarColor)}>
                      <span>{message.replyTo.user.initials}</span>
                    </div>
                    <span className="text-xs neon-purple">{message.replyTo.user.displayName}</span>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)] truncate">{message.replyTo.content}</p>
                </div>
              )}
              
              <div className={cn(
                "message-bubble relative",
                isOwn ? "own" : "other"
              )}>
                <p className="text-sm text-[var(--text-primary)]">{message.content}</p>
                
                {/* Message actions */}
                <MessageActions
                  messageId={message.id}
                  onReply={onReply}
                  onReaction={onReaction}
                  className={cn(
                    "message-actions md:absolute md:-top-3 static mt-2 flex justify-center md:justify-start",
                    isOwn ? "md:-left-16" : "md:-right-16"
                  )}
                />
              </div>
              
              {/* Reactions */}
              <MessageReactions
                messageId={message.id}
                reactions={message.reactions || {}}
                currentUserId={currentUser?.id}
                onAddReaction={(messageId, emoji) => onReaction(messageId, emoji, 'add')}
                onRemoveReaction={(messageId, emoji) => onReaction(messageId, emoji, 'remove')}
              />
            </div>
          </div>
        );
      })}

      {/* Typing indicators */}
      {typingUsers.map((user) => (
        <div key={`typing-${user.id}`} className="flex items-start space-x-3 mb-4 floating">
          <div className={cn("user-avatar", user.avatarColor)}>
            <span>{user.initials}</span>
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-sm font-medium neon-cyan">{user.displayName}</span>
              <span className="text-xs text-[var(--text-muted)]">transmitting...</span>
            </div>
            <div className="message-bubble other">
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
              </div>
            </div>
          </div>
        </div>
      ))}

      <div ref={messagesEndRef} />
    </div>
  );
}
