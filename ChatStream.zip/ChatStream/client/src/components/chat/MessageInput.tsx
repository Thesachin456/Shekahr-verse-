import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, AlertTriangle } from "lucide-react";
import ReplyPreview from "./ReplyPreview";

interface User {
  id: string;
  displayName: string;
  initials: string;
  avatarColor: string;
}

interface Message {
  id: string;
  content: string;
  user: User;
}

interface MessageInputProps {
  onSendMessage: (content: string, replyToId?: string) => void;
  onStartTyping: () => void;
  onStopTyping: () => void;
  error?: string;
  replyingTo?: Message;
  onCancelReply?: () => void;
}

export default function MessageInput({ 
  onSendMessage, 
  onStartTyping, 
  onStopTyping, 
  error,
  replyingTo,
  onCancelReply
}: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;

    onSendMessage(message.trim(), replyingTo?.id);
    setMessage("");
    if (onCancelReply) {
      onCancelReply();
    }
    
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    // Stop typing indicator
    if (isTyping) {
      onStopTyping();
      setIsTyping(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setMessage(value);

    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }

    // Handle typing indicator
    if (value.trim() && !isTyping) {
      onStartTyping();
      setIsTyping(true);
    }

    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set new timeout to stop typing indicator
    typingTimeoutRef.current = setTimeout(() => {
      if (isTyping) {
        onStopTyping();
        setIsTyping(false);
      }
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, []);

  const isValid = message.trim().length > 0 && message.length <= 500;

  return (
    <div className="glass-panel border-t border-[var(--neon-blue)]/20 relative z-10">
      {/* Reply preview */}
      {replyingTo && onCancelReply && (
        <ReplyPreview replyingTo={replyingTo} onCancel={onCancelReply} />
      )}
      
      <div className="p-4 md:p-6">
        <form onSubmit={handleSubmit} className="flex items-end space-x-2 md:space-x-4">
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            placeholder="Transmit your signal..."
            value={message}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            className="cyber-input resize-none min-h-[52px] max-h-[120px] pr-16 text-[var(--text-primary)] placeholder:text-[var(--text-muted)] w-full"
            rows={1}
            style={{ fontSize: '16px' }} // Prevents zoom on iOS
          />
          
          {/* Character limit indicator */}
          <div className="absolute bottom-3 right-4 text-xs text-[var(--text-muted)] pointer-events-none">
            <span className={`${message.length > 500 ? "text-red-400" : "neon-cyan"}`}>
              {message.length}
            </span>/500
          </div>
        </div>
        
        <Button 
          type="submit"
          className="cyber-button h-[52px] px-4 md:px-6 min-w-[52px]"
          disabled={!isValid}
        >
          <Send className="h-5 w-5" />
        </Button>
        </form>
        
        {/* Error display */}
        {error && (
          <div className="mt-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg backdrop-filter backdrop-blur-sm">
            <div className="flex items-center">
              <AlertTriangle className="h-4 w-4 text-red-400 mr-2" />
              <span className="text-sm text-red-400">{error}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
