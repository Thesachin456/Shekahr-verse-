import { Button } from "@/components/ui/button";
import { Settings, LogOut, Users, Wifi, WifiOff } from "lucide-react";

interface ChatHeaderProps {
  isConnected: boolean;
  activeUserCount: number;
  onToggleSidebar: () => void;
}

export default function ChatHeader({ isConnected, activeUserCount, onToggleSidebar }: ChatHeaderProps) {
  return (
    <header className="glass-panel border-b border-[var(--neon-blue)]/20 p-4 flex items-center justify-between relative z-10">
      {/* Left side - Logo and branding */}
      <div className="flex items-center gap-4">
        <div className="shkeharverse-logo glitch">
          ShkeharVerse
        </div>
        <div className="flex items-center gap-2 text-sm">
          {isConnected ? (
            <>
              <Wifi className="w-4 h-4 neon-green" />
              <span className="neon-green">ONLINE</span>
            </>
          ) : (
            <>
              <WifiOff className="w-4 h-4 text-red-400" />
              <span className="text-red-400">OFFLINE</span>
            </>
          )}
        </div>
      </div>

      {/* Center - Status info */}
      <div className="hidden md:flex items-center gap-4 text-sm text-[var(--text-secondary)]">
        <div className="cyber-input px-3 py-1 text-xs">
          <span className="neon-cyan">{activeUserCount}</span> USERS ONLINE
        </div>
      </div>

      {/* Right side - Controls */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleSidebar}
          className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px]"
        >
          <Users className="w-4 h-4 mr-1" />
          <span className="hidden sm:inline">USERS</span>
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px] hidden sm:flex"
        >
          <Settings className="w-4 h-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          className="cyber-button text-xs px-3 py-1 h-8 md:h-8 min-h-[44px] md:min-h-[32px] hidden sm:flex"
        >
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </header>
  );
}